---
name: micro-tool-site
description: 端到端构建并上线"单文件客户端工具网站"的完整流程——需求澄清、外部依赖验证、单文件页面构建、本地测试、GitHub 发布、Pages 部署、SEO 基建、流量统计、搜索收录、社区分发、每日数据管道迭代。Use whenever the user wants to build, launch, publish or promote a small client-side web tool or utility site: mentions making a 工具网站/在线工具/单文件网页/token 计数器/换算器/对比工具, wants to push a static page to GitHub Pages, asks for SEO/sitemap/analytics/Google 收录 for such a site, wants 宣传帖 for it, or needs to 起名/取名/命名 the site, repo, or domain (SEO-aware naming), or wants to 给站点配中文代号/国风主题风格（可选的品牌彩蛋体系）— even if they only ask for one phase of the process.
---

# 微工具站：从需求到上线的完整流程

为"单文件客户端工具网站"（计数器、换算器、对比工具等）提供端到端流程。
参考实现：一个 LLM Token 计数 + 多模型上下文/价格对比站（单文件 index.html）。

## 流程总览

| 阶段 | 产出 | 跳过条件 |
|---|---|---|
| 0 澄清 | 关键决策确认（含站名定稿） | 需求已完全明确 |
| 1 依赖验证 | 确认可用的 CDN/数据源清单 | 纯本地无外部依赖 |
| 2 构建 | index.html 单文件 | — |
| 3 本地测试 | 语法通过 + 浏览器冒烟通过 | — |
| 4 发布部署 | GitHub 仓库 + Pages 线上 URL + **注册表/主页同步** | 用户只要本地文件 |
| 5 SEO 基建 | meta/sitemap/JSON-LD/双语 URL | 用户没提搜索引擎 |
| 6 统计收录 | Analytics 代码 + GSC/Bing 收录 | 用户没提流量 |
| 7 社区分发 | 各平台宣传帖文案 | 用户没提推广 |
| 8 数据管道 | GitHub Action 每日数据 + 功能迭代 | 无外部数据源 |

用户只提单个阶段时只执行该阶段；说"做个网站并上线"时按序全跑。

## 用户环境与既定偏好（模板：与用户实际合作后沉淀填写，命中项阶段 0 不再问）

以下条目为**占位符模板**——把 `<...>` 换成你自己的环境并与用户确认后固化。**阶段 0 澄清时跳过这些项**，用户明确指定其他选项时才覆盖：

- **交付形态**：单文件 index.html（内联 CSS/JS，亮暗主题，Pages 零配置部署）
- **Logo 资产规矩（铁律）**：logo.png / favicon.png / apple-touch-icon.png 一律**切圆角**出图（半径约 20%，透明角 PNG），方角图不许上线；topbar `<img>` 和 favicon 引用一律带 `?v=N` 版本参数，**换图必须递增 N**——同名覆盖会被浏览器缓存吃掉，用户会看到"logo 没换"
- **Logo 源图用户出图制（可选约定）**：代号拍板后 logo 源图**由用户提供**，助手只做裁剪/圆角/三件套，**不自行设计 logo**；背景氛围图同理，须用户明示才做
- **语言**：界面与文档中英双语，**默认英语**预填（用户用中文交流、站点面向国际开发者时）
- **演示数据**：内置可连的公共演示端点；候选端点先 `curl` 验证 HTTPS + CORS（Wikimedia EventStreams 已验证可用；sse.dev 已失效勿用）
- **Git/GitHub**：`gh` 已登录 `<你的GitHub用户名>`；仓库直接建在账号下，public + Pages；**自有域名 `<你的主域名>`**（注册商自定）：用户站 → 主域名，项目站 → `<repo>.<你的主域名>` 子域名；新站建仓后跑 `<你的DNS工具目录>/new-site.sh <repo>`（DNS + cname 一条命令，凭据文件同目录、600 权限）；canonical/og:url 一律用 `https://<repo>.<你的主域名>/`
- **域名迁移坑（实战沉淀）**：gh api 绑 cname 会触发 GitHub 自动向远端提交 `Create CNAME`，本地必须 `git pull --rebase` 再 push；Let's Encrypt 证书签发几分钟到一小时，`https_certificate.state == "approved"` 后才可 `https_enforced=true`（**是 approved 不是 ready**；`-F https_enforced=true` 传布尔，`-f` 会 422）；`set -o pipefail` 下"grep 无匹配的管道"赋值返回非零会杀脚本（加 `|| :`）；`$var` 后紧跟全角字符（如括号）会被解析进变量名，写 `${var}`
- **GSC 验证**：优先用**网域资产 `<你的主域名>`**（DNS TXT 验证，一条覆盖所有子域名；从 GSC 复制 TXT 值 → 用你的 DNS 工具脚本写入）；HTML 验证文件方案仅作兜底
- **Cloudflare Web Analytics**：站点按 hostname 建（主域名及子域名选"手动安装 JS snippet"）；用户把 beacon 代码贴到对话里，加进 `</body>` 前
- **SEO 一次做齐**（双语 SEO）：hreflang(en/zh/x-default) + `?lang=` 深链（init 直读参数、切换时 replaceState 同步）、切换语言时同步 meta description/OG、WebApplication + FAQPage 两个 JSON-LD、sitemap 含 xhtml:link、og-image 1200×630
- **已上线站点清单**：`references/sites.md`（模板）——迭代已有站点前先读它，跳过建仓/部署/统计等已完成步骤；**新站上线后必须反向同步**（改 SKILL.md 无关，直接改文件）：① sites.md 追加小节 ② 主站主页加卡片 + 修筛选计数 + README 表，详见 sites.md 顶部「三处同步」
- **网站矩阵与站间导流**：主站 `<你的主域名>` 是总入口，其余全部是子站；子站在**任务完成点**互相导流——任务完成后弹层/卡片推荐功能上顺理成章的下一站（例：去水印完成 → 弹窗推荐图片压缩）。只推功能相邻站、可关闭、同一会话不重弹；**新站与老站迭代都必查**配对表 `references/sites.md`「矩阵导流」节，组件模式 `references/patterns.md` #8
- **子站统一风格基座**：所有子站共用同一套骨架（CSS 变量结构/亮暗主题/topbar/footer 代号彩蛋行/资产三件套规格/?v=N），**代号只换皮肤层**（色板+logo+彩蛋文案+可选氛围图）——风格统一方便维护，改共性组件时考虑是否全矩阵铺开；基座定义见 `references/codenames.md` 第二节开头
- **作者统一入口（可选，全矩阵铺法）**：每个子站**每个 HTML 页面**的顶栏 header 里放一个"作者名 · 独立开发者"导航链接，链到 `https://<你的主域名>/`（新窗口）——**复用各站顶栏现有的按钮/链接 class**（每站不同，读该站源码取现成的），让它长得像站点自己的导航项，**不许独立浮条**（footer 版、顶部独立条均被否——"底部不明显"/"太丑了"）；统一带 `author-entry` class：`<a class="<站点类> author-entry" href="https://<你的主域名>/" target="_blank" rel="noopener" title="<你的主域名>" style="text-decoration:none">作者名 · 独立开发者</a>`，`grep -rl author-entry` 全局定位；插入位置：有 nav 的放进 nav 末尾（FAQ 之后），无 nav 的放右侧按钮组第一个（语言按钮之前）；锚点元素如带 `title` 属性要写全（两处模板就差一个 title 踩过坑）；**各站 footer 不放措辞不一的主页链接**（"更多作品/工具矩阵"等旧写法清理后勿再引入）

## 阶段 0：需求澄清

用 AskUserQuestion 确认 3–4 个影响架构的决策，**每题附推荐项放在第一个选项**。工具站的通用问题：

1. 交付形态：单文件 HTML（推荐：双击可用、部署零配置）vs Vite+React 工程
2. 核心计算的数据来源与精度：官方库精确计算 + 离线估算兜底（推荐）vs 纯公式估算
3. 外部数据（价格/配置类）更新方式：在线同步 + 内置兜底（推荐）vs 写死在页面
4. 结果展示口径：按用户场景给 2–3 个选项

领域不同就替换对应问题（如汇率工具问"汇率源用什么"），已答过的不重复问。**"用户环境与既定偏好"一节列出的决策已有默认答案，不再问**，只问领域特有的问题。

## 站点命名（阶段 0 定稿，SEO 优先）

站名同时决定仓库名、子域名 `<repo>.<你的主域名>`、title/H1/og:site_name/JSON-LD name——命名是第一个 SEO 决策，不是装饰。在阶段 0 与其他澄清题一起用 AskUserQuestion 定稿：给 2–3 个**已通过下方验证**的候选，推荐项放第一个；用户只问"帮我想个名"时单跑本节即可。

- **结构 = 核心搜索关键词 + 短修饰词**：TokenScope、JSONSnap、SSEProbe、AudioScope 都是此模式。用户搜的是 "json formatter"、"sse debugger" 这类工具词，关键词进名字，title/H1/域名/品牌词四处同时吃到匹配
- **名字 ≤ 2 个词 ≈ ≤ 16 字符**：title 是 "Name — 关键词描述" 的拼法，总长 ≤ 60 字符才不被搜索结果截断，名字太长会挤掉关键词描述的位置
- **避开两个极端**：纯通用词（"JSON Formatter" 没有品牌词、排不过老站）和无关键词的纯品牌名（"Lens" 用户搜不到）；关键词 + 可品牌化修饰词才两头占
- **英文名**（站点面向国际开发者、默认英语），ASCII、可做小写仓库名；修饰词优先沿用既有词族（Lens / Inspector / Gems / Counter）保持作品集的家族感
- **进候选前必须验证三项**：
  1. **撞名**：WebSearch 候选名（带关键词）看是否已有同名知名产品/热门开源项目——有就换，否则品牌词搜索永远被它压着
  2. **仓库名**：`gh repo view <你的GitHub用户名>/<repo>` 确认未占用（仓库名小写，如 sse-probe、jsonsnap）
  3. **子域名**：对照 `references/sites.md` 确认 `<repo>.<你的主域名>` 未被已有站点占用
- 用户自带名字时同样跑三项验证，有冲突（尤其撞名）要明确告知利弊再让用户定夺

## 站点代号与主题风格（国风代号体系，可选）

每个站除英文站名外可配一个**中文代号**（品牌层彩蛋）：体系示例、在编池、逐站风格 spec、储备池、命名规则、落地工序见 `references/codenames.md`——给站点配代号或做主题风格改造前必读。

- **代号 ≠ 改站名**：英文站名/repo/子域名/canonical/SEO 关键词一律不动；代号只进品牌层（logo/favicon/主题色/og-image/footer 彩蛋行）
- 阶段 0 定英文名时**一并定代号**：从 codenames.md 储备池给 2–3 个候选（推荐项放第一），用户拍板才转正
- 代号定稿/更换/风格落地后同步 `references/codenames.md`（状态位标 ✅，迁移记录留痕）；风格落地的站再在 `sites.md` 对应小节补一行代号
- **logo 用户出图制**：代号拍板后 logo 源图由用户提供，助手只裁剪/圆角出三件套，不自行设计（含氛围图，须用户明示）

## 阶段 1：验证外部依赖

写代码**之前**逐个验证每个 CDN 资源和数据接口，不要凭记忆猜路径：

```bash
# npm 包文件结构（确认确切文件路径与导出形式）
curl -s "https://data.jsdelivr.com/v1/packages/npm/<pkg>@<ver>" | python3 -m json.tool
# 数据接口：状态码、CORS、大小、字段结构
curl -sI <url> | grep -iE 'HTTP/|access-control|content-length'
curl -s <url> -o /tmp/sample.json && python3 -c "import json; d=json.load(open('/tmp/sample.json')); print(list(d)[:5])"
```

- 动态 import 的库：主源 jsdelivr + 备源 esm.sh，两边都验证
- 数据接口确认：字段名（如 `max_input_tokens` vs `max_tokens`）、键名命名规则、URL 编码格式，**用真实数据抽样验证解析规则**（如"取最新版本号"的正则跑一遍样本）

## 阶段 2：构建单文件页面

架构约定（代码模式详见 `references/patterns.md`）：

- 单 index.html：内联 CSS（CSS 变量实现亮/暗主题，跟随系统 + 手动切换）+ 内联 `<script type="module">`
- 重计算库用动态 `import()` 加载，失败自动退化为本地估算，UI 徽标明确标注"精确/估算"
- 外部数据三级回退：**每日构建小 JSON → 直连全量接口 → 内置兜底数据**；在线数据与兜底**逐字段合并**（`d = {...fb}; if (live) 逐字段用非空 live 覆盖`），不要整条替换
- 所有 fetch 加 AbortController 超时（小文件 8s，大文件 15s）
- 大文本保护：超过阈值（如 30 万字符）跳过精确计算走估算，防主线程卡死；徽标随之变"估算"
- 中英双语：`data-i18n` 属性 + 字典对象，切换时更新 `<html lang>` 和 `<title>`；语言优先级 URL `?lang=` → localStorage → 浏览器语言；**HTML 中预填默认语言文案**（爬虫不执行 JS 也能看到）
- 头部状态栏显示数据来源与更新时间；隐私卖点（纯本地计算、文本不上传）写进页面和宣传物料
- 新增带 `data-i18n` 的元素时**手动写入默认文案**，不要指望预填脚本（它只填空元素）
- **任务完成点导流**：核心任务完成后的结果区/轻弹层推荐矩阵内功能相邻的子站（规矩与配对表见「既定偏好·网站矩阵与站间导流」，组件模式 patterns.md #8）

## 阶段 3：本地测试

1. 语法检查：提取 module 脚本 → `node --check`
2. 浏览器自动化**不能直接打开 file:**，先 `python3 -m http.server 8747` 起本地服务
3. 用 control-browser 技能冒烟：核心功能、中英切换、筛选/排序/刻度、超长输入保护、明暗主题、截图目检
4. 定位元素优先用 id，避免文本歧义（"EN"会同时匹配"OpenAI"按钮）；验证复制功能用拦截 `navigator.clipboard.writeText` 的方式（`readText` 需要窗口焦点会失败）
5. 用 `history.replaceState` / 事件派发代替无法通过 Playwright actionability 检查的点击

## 阶段 4：GitHub 发布 + Pages 部署

```bash
gh auth status                                  # 确认登录与协议
git init -b main && git add -A && git commit -m "..."
gh repo create <name> --public --source=. --remote=origin --push
gh api -X POST repos/<owner>/<name>/pages -f 'source[branch]=main' -f 'source[path]=/'
<你的DNS工具目录>/new-site.sh <name>            # 加 DNS CNAME + 绑子域名 <name>.<你的主域名>（幂等）
<你的DNS工具目录>/enforce-https.sh <name> &     # 后台轮询证书（state=approved）并自动强制 HTTPS，几分钟~1h，不阻塞会话
```

- 免费版 Pages 要求**公开仓库**（向用户说明这一点）
- **上线同步（必做，勿当可选项）**：跑完后按 `references/sites.md` 顶部「三处同步」执行——① sites.md 追加本站小节；② 主站主页仓库（本地目录按 sites.md 登记）工具矩阵加卡片（data-cat 按内容归类）+ 修正筛选按钮硬编码计数 + README 作品表加行，commit + push；③ 下线站反向移除。不做这步，下次迭代会漏站/计数漂移
- 部署后 sleep ~60s 用 curl 验证 200（新域名是 http 200，证书就绪前 https 握手失败属正常；HTTPS 由 `enforce-https.sh <repo>` 后台自动补齐，完成后向用户汇报即可）
- **Pages 缓存 `max-age=600`**：部署后立刻验证会拿到旧页，带随机查询参数绕过
- 之后每次 `git push` 自动重新部署，约 1 分钟生效

## 阶段 5–7：SEO / 统计收录 / 社区分发

完整清单、命令、模板与平台规则见 `references/seo-launch.md`。快速要点：

- **SEO**：H1 含关键词、meta/description/canonical/OG/Twitter/favicon、sitemap.xml+robots.txt、JSON-LD（WebApplication+FAQPage）、`?lang` 双语 URL + hreflang、og-image 1200×630（可用页面截图 sips 裁剪）
- **统计**：Cloudflare Web Analytics（免费无 Cookie），深链 `dash.cloudflare.com/?to=/:account/web-analytics`，用户给 token 后把 beacon 加进 `</body>` 前
- **收录**：GSC 用"网址前缀"+HTML 验证文件（github.io 做不了网域验证）；sitemap 提交后"无法读取"多为误报等 72h，更快的路是网址检查→请求编入索引；Bing 从 GSC 导入
- **分发**：Reddit/V2EX/Product Hunt/Show HN 各有语气模板；错开发布、发完守评论区、明说"我是作者"

## 阶段 8：数据管道与迭代

有外部数据源的工具站标配 GitHub Action（模板见 `references/patterns.md`）：每日拉取全量 → 解析成几十 KB JSON → 提交进仓库 → Pages 自动重新部署。解析逻辑与页面保持一致，脚本里注明"需与页面同步"。

运营迭代：用户/评论区的问题沉淀为 FAQ（双语 + 预填）；高频需求做成新功能（如月度成本计算器）；广告变现等有回访用户再谈（EthicalAds 类原生广告优先于 AdSense）。

## 高频坑清单（每条都真实踩过）

| 坑 | 解法 |
|---|---|
| 浏览器自动化打不开 file:// | 本地 http.server 起服务再测 |
| 部署后浏览器拿到旧页（缓存 max-age=600） | 带随机查询参数验证 |
| 在线数据缺字段（如托管商键无 ctx/价格） | 逐字段 `??` 兜底合并，勿整条替换 |
| localStorage 读出的时间字符串直接 new Date → Invalid Date | 先 `Number()` |
| 超长文本精确计算卡死主线程 | 超阈值走估算 + 徽标降级 |
| 版本号格式混杂（`4-5` vs `4.5` vs `latest`） | `split(/[.-]/)` 解析为数字数组比较 |
| 同名模型多条目（官方键无价格、托管键有价格） | 排序先"有价格优先"，再按版本最新 |
| Reddit 自动过滤器删新号带链帖子 | 版主申诉信 + 每日评论养号，勿重复发 |
| GSC sitemap"无法读取" | 新站误报，等 72h；用网址检查直接请求收录 |
| Playwright 文本定位歧义（"EN"匹配"OpenAI"） | 用 id/CSS 选择器定位 |
| 内嵌 WebView 冻结 requestAnimationFrame（即便可见） | 动画/节流用 setTimeout 而非 rAF |
| 内嵌 WebView 忽略 `behavior:'smooth'` | 滚动后 120ms 检测未移动 → setTimeout 步进动画兜底 |
| 内嵌 WebView 完全不派发 scroll 事件 | scrollspy 加 250ms 轻量轮询（document.hidden 时跳过） |
| i18n 新增元素文案为空被爬虫看到 | 手写默认文案进 HTML |
| data-i18n 用 innerHTML 替换，抹掉容器内带 id 的子元素（如统计栏 `<b id="stEvents">`），后续渲染抛错中断主流程 | i18n 文本放独立的内层 `<span data-i18n>`，容器只负责包裹，id 元素与 i18n 元素不嵌套 |
| Cloudflare Web Analytics 对 github.io 域名点 auto-inject 报 "hostname does not belong to your account" | 添加站点时选"手动安装 JS snippet"，用户贴 beacon 代码过来加到 `</body>` 前 |
| browser 自动化的 evaluate 里写多语句字符串报 "Unexpected token ';'" | 用 `(() => { … })()` IIFE 包裹；取值尽量一条表达式 |
| `?lang=` 参数只在 i18n 优先级里"写了"，init 没实现，sitemap 深链全显示默认语言 | init 时 `URLSearchParams` 直读 `lang`/`s` 等参数；切换语言时 `history.replaceState` 同步进 URL（保留 hash） |
| macOS 本机 zsh：`for r in $repos` 不按空格分词，整个字符串当一个值跑一轮（批量 gh api 全 404，还误以为没执行） | 用内联列表 `for r in a b c` 或 `${=repos}`；批量操作前后各打印关键状态确认 |
| GitHub 侧整批清除账号的自定义域名证书（API `https_certificate=null`，边缘回落 `*.github.io` 证书，全网 HTTPS 报 ALTNAME_INVALID；对照他人 Pages 站证书正常即可确认为账号级） | 逐仓库 `DELETE /pages` → sleep 2 → `POST /pages -f source[branch]=main -f source[path]=/`，cname 自动从仓库 CNAME 文件恢复，证书 1–4 分钟重新 approved；期间 HTTP 中断 1–2 分钟。诊断时本机 IPv4 到 185.199.x.x 会瞬态断连，用外部网络（WebFetch）或 IPv6 复测排除本机因素 |
