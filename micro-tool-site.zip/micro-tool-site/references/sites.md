# 已上线微工具站点清单（模板）

> 脱敏模板：原版是作者的站点运营登记表（域名/仓库/本地路径/事故记录/逐站迭代史），此处保留登记结构、域名运维实战教训与工程教训速查，示例条目均为虚构。每上线一个站，照「示例站条目」格式追加一节。

迭代已有站点前先读本表：跳过建仓/部署/统计/GSC 等已完成步骤，直接在本地目录改代码 → push 部署。

**上线/变更后必做的三处同步（硬性步骤，不省略）**：
1. **本表追加一节**（新站）或更新对应小节（域名/仓库/定位变更）：本地目录、仓库、线上 URL、形态、迭代注意
2. **主站主页收录新站**：主页仓库的 index.html 工具矩阵 `.grid` 复制一张卡片（data-cat 按内容归类 ai/dev/media/rank）+ **同步修正筛选按钮计数**（删站后计数会漂移）+ README 作品表加/删行 → commit + push
3. **站点下线/删除时**：本表小节标记 `[已删除]` 保留教训、主页卡片与 README 行移除、（可选）远程仓库删除

## 域名架构（示例结构）

- **自有域名 `<你的主域名>`**：用户站 `<你的GitHub用户名>.github.io` → 主域名（作品集主页）；每个项目站一个子域名 **`<repo>.<你的主域名>`**
- 旧 github.io 地址全部 301 到新域名；各站 canonical/og:url/sitemap 批量换新
- **DNS/绑定自动化**：`<你的DNS工具目录>/`（DNS API 纯签名客户端 + 凭据文件 600 权限 + `new-site.sh`）。新站绑子域名：`./new-site.sh <repo>`；加 GSC 网域验证 TXT：`python3 dns-tool.py txt <你的主域名> '<token>'`
- **Pages 自定义域运维实战教训（通用，值得全读）**：
  - gh api 绑 cname 后 GitHub 会自动向远端提交 `Create CNAME`，本地需 `git pull --rebase` 再 push；证书签发几分钟到一小时，就绪后 `gh api -X PUT repos/<owner>/<repo>/pages -F https_enforced=true`
  - **证书整批失效事故类型**：GitHub 侧可能把账号下所有自定义域名的证书记录清除（API `https_certificate=null`、边缘回落 `*.github.io` 证书 → 全网浏览器 ERR_TLS_CERT_ALTNAME_INVALID），对照他人 Pages 站证书正常可确认为账号级而非 GitHub 全局。**修复法**：逐仓库 `gh api -X DELETE repos/<owner>/<repo>/pages` → sleep 2 → `-X POST -f 'source[branch]=main' -f 'source[path]=/'`，约 1–4 分钟证书重新 approved，HTTP 中断窗口 ≈1–2 分钟；**若删建后仍卡在无证书，推一个空提交**（`git commit --allow-empty` + push）触发全新构建/签发流程，实测比 POST /pages/builds 重建有效
  - **用户站（github.io 主页仓库）证书失效不能 DELETE/POST**：返回 422 "Deactivating GitHub Pages for this repository is not allowed"。改用：`PUT /pages --input - <<< '{"cname":null}'` 解绑 → 数秒后 `PUT -f cname=<你的主域名>` 重绑（或全量重写 source + cname）；签发可滞后数小时，期间 http 全程可用、各项目子域名不受影响。cname 变更同样触发 GitHub 自动提交 CNAME 增删，本地 `git pull --rebase`；收尾可挂后台长轮询（每 3 分钟查 state，approved 后自动 `-F https_enforced=true`）
  - **个别站卡住的根因逐站排查**：① 权威 DNS 的 CNAME 记录丢失（NXDOMAIN，外部访客完全不可达，仅本机 DNS 缓存还能打开）→ 在 DNS 服务商补 `CNAME <repo> <你的GitHub用户名>.github.io` + 修仓库里过期的 CNAME 文件后签发成功；② GitHub 签发队列随机丢弃，最长滞后数小时，API 无法催——删建/空提交都无效时无需继续催，挂后台轮询等队列即可
  - 诊断要点：`curl -ksv` 看证书 subject 判定回落；`dig @8.8.8.8` + 权威 NS 双查 DNS；用外部网络（WebFetch）复测证书错误以排除本机网络因素（本机到 185.199.x.x 可能瞬态断连，IPv6 正常，`curl --resolve` 强制 IPv4 会误报 000）
- **统计**：Cloudflare Web Analytics 按 hostname 建站；各站 `</body>` 前埋统一 beacon（token 不落文档，从已上线站源码取）
- **GSC**：网域资产 `<你的主域名>`（DNS TXT 已验，一条覆盖所有子域名）；sitemap 按子域逐条提交

## 矩阵导流（子站间互推模板）

矩阵定位：**主站是总入口，其余全部是子站**。子站在**任务完成点**互相导流——任务完成后弹层/卡片推荐功能上顺理成章的下一站。规矩：只在完成点推、只推功能相邻站（不硬推）、可关闭、同一会话不重弹（sessionStorage）、双语、链接带 `?from=<站>`；组件模式见 `patterns.md` #8。**新站上线与老站迭代必查此表**：本站完成点该推谁？本站是否已被别人推（文案/落地页要不要配合）？新增或落地导流位后回写本表状态。**一站一主位**：每站完成点只放 1 个弹层（结果区弱推荐行是非弹层的例外形态）。

**组件统一形态**：`.mxf` 样式 + `#mxFunnel` 卡片 + 独立非模块 `<script>`（不碰站点 JS）；脚本暴露 `window.mxFunnel()`，完成回调一行 `try{window.mxFunnel&&window.mxFunnel()}catch(e){}` 触发；**F 对象必须带 `url` 字段**（脚本用 `a.href=F.url` 覆盖 markup 静态链接，漏了 CTA 就变 `/undefined`）；语言在弹出时刻读 `document.documentElement.lang`。特例技巧：对比/弹窗类站点用 MutationObserver 监听 modal **关闭后**再弹（不遮弹窗）；下载类站点用 capture 委托 `a[download]` 点击（站点 JS 零改动）。

| 从站（完成点） | 推到 | 时机与话术方向 | 状态 |
|---|---|---|---|
| 示例：去水印站（任一下载后） | 图片压缩站 | 弹层："去完水印，顺手把体积也压小？"（sessionStorage 记忆键） | 示例行 |
| 示例：JSON 工具站（首次成功解析 ≥300 字符） | Token 计数站 | 弹层："数数这段 JSON 花多少 token" | 示例行 |
| 示例：Token 计数站（对比 modal 关闭后，MutationObserver） | 模型排行站 | "模型选好了？算算 prompt 花多少钱" | 示例行 |
| （新站照此格式追加；受众太泛/总入口不设导流位） | | | 🆕 |

## 通用工程教训速查（各站实战沉淀，与具体站解耦）

- 重引擎放经典 `<script>`（非 module，挂 window），配 Node 单测先行（合成场景 + PSNR 断言），进浏览器前先过——OOM 级 bug 首测即抓；引擎循环边界用 `w*h`，不信任数组长度（scratch 缓冲区复用残留会爆栈）
- `display:none` 的 `<video>` 在 WebKit 不解码帧（canvas drawImage 全黑）→ 离屏布局（position:fixed 移出屏幕）+ loadedmetadata 后 `currentTime=0.033` 触发首帧解码
- 内嵌 WebView/IAB 一揽子：调用间隙随机重载清内存状态（跨调用断言要重灌数据）；动态 `import()` 被改写不可用（测动态 import 走页面内代码路径）；`disabled` 按钮 `.click()` 静默无效（程序化设状态后手动 `disabled=false`）；后台标签定时器节流（持久化断言等 ≥1.5s 或直接读 localStorage）；rAF 冻结（动画一律 setTimeout + IntersectionObserver/visibilitychange 双闸）；`scroll-behavior:smooth` 会让**所有** scrollTo 变 smooth 全被冻结 → 步进兜底；getByRole click 超时 → DOM 原生 `el.click()`；重计算（wasm 编译）期间标签崩成 about:blank → 重型 E2E 用 puppeteer-core + 系统 Chrome
- 模块 init 早期调用 UI 更新函数，元素变量还在 TDZ → ReferenceError 中断整个 init（症状：部分功能可用，难排查）：加 `uiReady` 门闩，init 尾部置 true 才放行
- canvas 画 `<video>` 的编辑器：重绘必须覆盖整个播放周期（播放期 33ms interval 持续重绘，不能只在 seeked/pause 重绘——否则进度条走、画面卡第一帧）；demo canvas 漏 `ctx.scale(DPR,DPR)` 在 DPR=2 屏才显形
- CSS `display:flex` 会覆盖 `hidden` 属性（UA 的 [hidden]{display:none} 输给任何作者 display 声明）→ 全局 `[hidden]{display:none!important}`；新页面有 fixed 浮层一律先查这条
- 文字自适应绘制：fitBlock 类函数会改 `ctx.font`，"先算 A 再画 B" 会让 B 用 A 的字号——每段文字绘制前显式重设字体；末行孤字约束；空间不足先降级副标题再降级装饰，杜绝小尺寸重叠
- fetch 进度条别用 content-length 算百分比——CDN 返回 gzip 长度，解压流超出会算出 >100%；对已知大小文件用固定估值
- @ffmpeg/ffmpeg 0.12 传 classWorkerURL 会以 `{type:"module"}` 建 worker，UMD 块内 importScripts 不存在 → worker 静默挂死、load 永久 pending；解法：同源放 UMD 分块文件，不传 classWorkerURL
- 大面积修复蒙版纯 Telea 纵向拖影严重 → 金字塔粗尺度到细尺度 + 扩散松弛；引擎只处理蒙版包围盒(+pad) 省内存
- 清单/榜单类数据**凭记忆写会大面积翻车**（多年前印象 vs 实测差异巨大）→ 脚本实查（GraphQL 批量 25/批 + 单仓兜底 + 缓存 + 每周巡检 workflow 自动刷新 + 待裁决项开 Issue）
- 生成器注入静态页的项目：数据唯一来源是生成脚本；**手改页面必须同步生成器模板**，否则下次 regen 冲掉；HTML 注释标记放 script 标签**外**（放里面会并进 textContent 导致 JSON.parse 失败）
- og-image 快捷法：`setViewportSize 1200×630` 后整页截屏即成品，免裁剪
- 本地测试端口先 `lsof -i :<port>` 验空——端口被占时绑失败也可能返回 200，差点误判
- evaluate 注入大 blob：spread 参数 >32KB 爆栈 → FileReader-base64 落盘验证；录屏/摄像头类可用 canvas.captureStream + OscillatorNode→MediaStreamDestination 假流做免权限全流程 E2E
- 导出类站点验收：产物 blob 落盘后用 ffprobe 验时长/编码，A/B 帧目检

## 示例站条目（虚构，照此格式逐站追加）

## DemoTool — 演示去水印工具（20XX-XX-XX 上线）

- 本地目录：`<你的本地项目根目录>/demo-tool`；仓库：`https://github.com/<你的GitHub用户名>/demotool`（public，main → Pages）
- 线上：`https://demotool.<你的主域名>/`（HTTPS 已强制；代号：**示例代号** ✅ 20XX-XX-XX 钦定，spec 见 codenames.md）
- 定位：一句话说清细分与打法（例：图片去水印细分——涂抹标记 + 修复算法重建背景，主打纯本地隐私 + 批量并发）；SEO 词=中文词/english keywords/long tail
- 形态：单文件 index.html（零外部 JS 依赖、零构建）；中英双语默认英语（`?lang=` 深链 + hreflang）；亮暗主题（auto/light/dark）
- 功能要点：核心能力 3–6 条（编辑器/引擎档位/批量/导出格式/快捷键…）；有重引擎时注明"改引擎必须先跑 `node scripts/test-engine.mjs`"
- 引擎与测试：引擎放经典 `<script>` + Node 单测（PSNR 断言 + 回归）；自动化测试坑见上方「通用工程教训速查」
- SEO：canonical、hreflang(en/zh/x-default)、WebApplication+FAQPage JSON-LD（FAQ×5 与页面一致）、sitemap.xml（xhtml:link）、og-image.png（1200×630）、robots.txt
- 统计：Cloudflare beacon 已加 `</body>` 前
- GSC：验证文件已部署；用户侧添加前缀 `https://demotool.<你的主域名>/` 点验证、提交 sitemap
- 迭代注意：改完 `git push` 自动重部署约 1 分钟，验证带随机 `?v=`；i18n 改动同步 en/zh 两份字典 + JSON-LD FAQ；导流弹层见「矩阵导流」表；**二期候选（未排期）**：…

（以下每个上线站照此格式追加一节；下线站标记 `[已删除]` 保留教训勿删节）
