# SEO、统计收录与社区分发详细手册

阶段 5–7 的完整操作手册。所有 `<域名>` 占位符替换为实际站点 URL。

## 1. SEO 基建清单

### head 模板

```html
<title>产品名 — 核心关键词中文 & 英文关键词 | Brand</title>
<meta name="description" content="一句话说清功能+亮点+免费/隐私卖点，中英关键词都放。">
<link rel="canonical" href="https://<域名>/">
<link rel="alternate" hreflang="zh" href="https://<域名>/?lang=zh">
<link rel="alternate" hreflang="en" href="https://<域名>/?lang=en">
<link rel="alternate" hreflang="x-default" href="https://<域名>/">
<link rel="icon" type="image/svg+xml" href="favicon.svg">
<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<meta property="og:type" content="website">
<meta property="og:site_name" content="Brand">
<meta property="og:title" content="分享卡片标题（可英文为主）">
<meta property="og:description" content="分享卡片描述">
<meta property="og:url" content="https://<域名>/">
<meta property="og:image" content="https://<域名>/og-image.png">
<meta property="og:locale" content="zh_CN">
<meta property="og:locale:alternate" content="en_US">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="...">
<meta name="twitter:description" content="...">
<meta name="twitter:image" content="https://<域名>/og-image.png">
<script type="application/ld+json">
{"@context":"https://schema.org","@graph":[
 {"@type":"WebApplication","name":"...","url":"...","applicationCategory":"DeveloperApplication",
  "operatingSystem":"Any","offers":{"@type":"Offer","price":"0","priceCurrency":"USD"},
  "inLanguage":["zh-CN","en"],"description":"..."},
 {"@type":"FAQPage","mainEntity":[
  {"@type":"Question","name":"与页面可见 FAQ 一致的问题",
   "acceptedAnswer":{"@type":"Answer","text":"与页面一致的答案"}}]}
]}
</script>
```

要点：
- **H1 只有一个**，含核心关键词；页面主内容**预填默认语言文案**（爬虫不执行 JS）
- title 总长控制在 ~60 字符内：站名（含核心关键词，阶段 0 命名节定稿）优先保留，放不下就砍次要关键词/Brand 后缀
- JSON-LD 的 FAQ 必须与页面可见 FAQ 一致，否则可能被判结构化数据滥用
- favicon 用 SVG 文件（勿用 data URI 也可，文件便于各处复用）

### sitemap.xml + robots.txt

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
  <url><loc>https://<域名>/</loc><changefreq>weekly</changefreq><priority>1.0</priority>
    <xhtml:link rel="alternate" hreflang="zh" href="https://<域名>/?lang=zh"/>
    <xhtml:link rel="alternate" hreflang="en" href="https://<域名>/?lang=en"/>
  </url>
</urlset>
```

```
User-agent: *
Allow: /

Sitemap: https://<域名>/sitemap.xml
```

### OG 分享图

1200×630 PNG。快捷做法：截一张站点深色首屏 → `sips -z 844 1200 img.png && sips -c 630 1200 img.png`（居中裁切）。

### 双语 SEO

- 语言切换时 `history.replaceState` 同步 `?lang=` 参数（默认语言保持干净 URL）
- `?lang=en` 让英文版有独立可收录 URL；配合 hreflang；首访语言跟随 `navigator.language`

### 内容矩阵（有流量后的增长引擎）

一个长尾搜索词 = 一个页面：模型专页（`/gpt-5-token-counter`）、指南页（"1000 个汉字是多少 token"）、每日更新的对比表页。每页独立 title/description/FAQ，嵌入同一核心工具。

## 2. 流量统计

| 方案 | 费用 | 适用 |
|---|---|---|
| Cloudflare Web Analytics（首选） | 免费、无 Cookie | 上线即装，无需同意弹窗 |
| GoatCounter | 非商用免费 | 极简，统计页可公开 |
| GA4 | 免费 | 要合规横幅，开发者站被拦截多 |
| Plausible | $9/月起 | 认真运营期再上 |

Cloudflare 接入：深链 `https://dash.cloudflare.com/?to=/:account/web-analytics`（找不到入口时用深链；Web Analytics 是账号层级功能）→ Add a site → 填主机名（无需迁移 DNS）→ 复制 beacon → 用户把 token 给你 → 加到 `</body>` 前：

```html
<script type='module' src='https://static.cloudflareinsights.com/beacon.min.js' data-cf-beacon='{"token": "<TOKEN>"}'></script>
```

验证：`performance.getEntriesByType('resource')` 里出现 `cloudflareinsights.com/beacon`。部署后浏览器可能有 10 分钟缓存，验证带随机参数。

## 3. 搜索收录

1. **Google Search Console**：添加资源选「网址前缀」（github.io 等子域托管做不了"网域"DNS 验证）→ 验证方式选「HTML 文件」→ 文件放仓库根目录推送 → 线上 curl 确认后点验证
2. 提交 sitemap。**提交后"无法读取"是新站常见误报**：等 72h，勿反复重交；更快的路是「网址检查」→ 输入首页 URL →「请求编入索引」
3. **Bing Webmaster**：登录选「从 Google Search Console 导入」一键同步
4. 预期：新站沙盒期约 3 个月，前期自然搜索≈0 属正常

## 4. 社区分发

### 发布节奏

- 多渠道**错开 2–3 天**，不同时轰炸；发完 1–2 小时守评论区（互动率决定帖子生死）
- 明说"我是作者/I built"；用完整链接不用短链；发完 24h 用统计面板 Referrers 复盘渠道

### 各平台要点

| 渠道 | 节点/版块 | 语气与格式 |
|---|---|---|
| Reddit | r/LocalLLaMA 等 | 技术细节第一人称；列功能、已知局限、求反馈；**新号必被过滤器拦**：发版主申诉信 + 每日评论养号，勿重复发帖；也可只发 GitHub 仓库链接（信誉更好） |
| V2EX | 分享创造 | 缘由 → 功能列表 → 技术实现 → 开源链接 → 求喷；标题不带感叹号营销词 |
| Product Hunt | — | Tagline ≤60 字符；Description 一段；上线后自己发 Maker's comment（痛点→三个重点→开源链接）；周二~四发，找朋友同时段 upvote |
| Hacker News | Show HN | 标题严格 `Show HN: Name – 一句话`；正文短、事实性、无营销腔 |

### 文案通用骨架

1. 痛点一句话（我因为 X 烦，所以做了这个）
2. 在线地址 + 开源地址
3. 功能列表（3–6 条，每条一句）
4. 技术实现一段（纯本地/单文件/数据来源——给技术社区的信用）
5. 已知局限（主动交代= credibility）
6. 求反馈（点名想要的建议类型）

## 5. 变现阶梯（用户问起时）

- <1万 PV/月：零广告，最多捐赠链接
- 1万–5万：EthicalAds / Carbon Ads（开发者向原生广告，无硬流量门槛）或厂商赞助位
- 10万+：AdSense 补充 + 直投；此时应已换自有域名（github.io 上 AdSense 难过审、百度联盟要求备案）
- 触发信号是"有回访用户 + 周UV稳定增长"，不是 PV 数字本身
