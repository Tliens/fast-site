# 代码模式与模板

单文件工具站的已验证代码模式。按需取用，别整段照抄——贴进项目前按领域改参数。

## 1. 中英 i18n + 内容预填

结构：元素挂 `data-i18n="key"`（文本）/ `data-i18n-ph="key"`（placeholder），字典对象存双语文案，切换时 `textContent` 覆盖。

**关键：HTML 里直接预填默认语言文案**（爬虫可见），JS 加载后覆盖。批量预填脚本（从字典提取 zh 值填入空元素，幂等可重跑）：

```python
import re
html = open('index.html', encoding='utf-8').read()
zh = re.search(r'zh: \{(.*?)\n  \},\n  en: \{', html, re.S).group(1)
# 注意：字典里一行可能有多个键值对，不能用 ^行首锚定
pairs = dict(re.findall(r"(\w+):'([^'\\]*)',", zh))
html = re.sub(r'data-i18n="(\w+)"></',
              lambda m: f'data-i18n="{m.group(1)}">{pairs.get(m.group(1), m.group(1))}</', html)
html = re.sub(r'data-i18n-ph="(\w+)"(?! placeholder)',
              lambda m: f'data-i18n-ph="{m.group(1)}" placeholder="{pairs.get(m.group(1), "")}"', html)
open('index.html', 'w', encoding='utf-8').write(html)
```

之后**新增的 i18n 元素要手写默认文案**，脚本只处理空元素。

语言优先级：`?lang=` URL 参数 → localStorage → `navigator.language`。切换时 `history.replaceState` 同步 URL（默认语言保持干净 URL），并更新 `document.title` 与 `<html lang>`。

## 2. 外部数据三级回退加载

```js
function fetchWithTimeout(url, ms){
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  return fetch(url, { cache: 'no-store', signal: ctrl.signal }).finally(() => clearTimeout(t));
}
async function bootData(){
  setStatus('loading');
  try{ await loadDailyData(); }            // ① 每日构建的几十 KB data.json（同仓库）
  catch(e){
    try{ await fetchLiveDirect(); }        // ② 直连全量外部接口（手动刷新也走这条）
    catch(e2){
      const c = loadCache();               // ③ localStorage 缓存（直连成功过才有）
      if (c){ apply(c); state.dataSource = 'cached'; }
      else state.dataSource = 'bundled';   // ④ 内置兜底
    }
  }
  setStatus(state.dataSource); renderAll();
}
```

**在线数据与内置兜底逐字段合并**（外部数据常见缺字段）：

```js
const d = { ...m.fb };                                // 内置兜底
if (m.live) for (const [k, v] of Object.entries(m.live)) if (v != null) d[k] = v;
```

## 3. "取最新版本"解析器（外部模型/产品清单类数据）

数据源键名混杂：`gpt-5`、`gpt-5.1`、`claude-sonnet-4-5`、`-latest`、官方键无价格而托管键有。解析规则：

```js
const vt = s => String(s).split(/[.\-]/).map(Number);   // '4-5'→[4,5]，'4.5'→[4,5]
function pickEntry(db, patterns){
  let best = null, bestScore = null;
  for (const re of patterns) for (const k of Object.keys(db)){
    const e = db[k];
    if (!e || e.mode !== 'chat') continue;              // 按领域过滤
    const m = k.match(re); if (!m) continue;
    const v = m[1] ? vt(m[1]) : [0];
    const score = [e.price != null ? 1 : 0, v];         // 先"有价格优先"，再版本最新
    if (bestScore === null || score[0] - bestScore[0] > 0 ||
       (score[0] === bestScore[0] && cmpArr(score[1], bestScore[1]) > 0)){
      best = e; bestScore = score; best.key = k;
    }
  }
  return best;
}
```

显示名从键名美化（`claude-sonnet-4-5` → `Claude Sonnet 4.5`），但要有 `baseName` 兜底——解析失败或字段缺失时页面不能出现空名字。

**写正则后必须拿真实数据样本跑一遍**（多个版本号格式、无捕获组、`latest` 后缀都要验证），否则会静默漏配。

## 4. 大文本保护

重计算（分词/编码）在大输入下会卡死主线程：

```js
const LIMIT = 300000;
function countExact(text){
  if (!enc || text.length > LIMIT) return null;   // 超限走启发式
  return enc.encode(text).length;
}
```

徽标/UI 状态必须随之降级（"精确"→"估算"），否则界面显示的是估算值却标着"精确"。

## 5. GitHub Action 每日数据管道

`scripts/update-data.mjs`（Node 18+，自带 fetch）：拉全量 → 用与页面**一致的解析逻辑**裁剪成小 JSON → 写 `data.json`。脚本顶部注释"需与页面内联脚本保持同步"。

`.github/workflows/update-data.yml`：

```yaml
name: Update data
on:
  schedule:
    - cron: '13 3 * * *'   # 避开整点拥挤
  workflow_dispatch:
permissions:
  contents: write
jobs:
  update:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: node scripts/update-data.mjs
      - name: Commit if changed
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
          git add data.json
          git diff --cached --quiet || (git commit -m "chore: daily data sync" && git push)
```

push 会自动触发 Pages 重新部署。首次建好后手动 `gh workflow run <name>` 验证跑通。

## 6. 复制摘要按钮（带降级与反馈）

```js
btn.onclick = async () => {
  const txt = buildSummary();                        // 组好纯文本摘要 + 站点链接
  try{ await navigator.clipboard.writeText(txt); }
  catch(e){
    const ta = document.createElement('textarea');
    ta.value = txt; document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); }catch(_){}
    ta.remove();
  }
  btn.textContent = t('copied');                     // "已复制 ✓"
  setTimeout(() => btn.textContent = t('copyResults'), 1500);
};
```

测试时不要用 `navigator.clipboard.readText()`（需窗口焦点，自动化环境必失败）——先拦截 `writeText` 捕获参数再点击。

## 7. 部署后验证

```bash
curl -s -o /dev/null -w '%{http_code}' "https://<域名>/"
# 浏览器验证带随机参数绕过 Pages 的 10 分钟缓存：
# goto("https://<域名>/?v=" + Date.now())
```

语法检查：提取 `<script type="module">` 内容 → `node --check`。

## 8. 任务完成点导流（矩阵互推）

任务完成时机推荐矩阵内功能相邻的子站：轻弹层或结果区卡片（非阻塞遮罩），可关闭，**同一会话只弹一次**（sessionStorage——别用 localStorage 永久压制，回访用户还有转化窗口）。文案双语，带一句话理由而不是光秃秃的链接：

```js
const FUNNEL = {
  key: 'funnel_pictool_v1',            // 会话记忆键；换目标站/话术就换键名
  card: {
    url: 'https://pictool.example.com/?from=marktool',
    zh: { title: '顺手压小体积？', why: '去完水印，把图片也压到更小', btn: '去 PicTool' },
    en: { title: 'Shrink it too?', why: 'Watermark removed — now compress it', btn: 'Open PicTool' }
  }
};
function maybeFunnel(){                     // 在"任务完成"回调里调
  if (sessionStorage.getItem(FUNNEL.key)) return;   // 本次会话只弹一次
  renderFunnelCard(FUNNEL.card);
  closeBtn.onclick = () => { sessionStorage.setItem(FUNNEL.key, '1'); hide(); };
}
```

- 链接带 `?from=<站>`，统计侧便于辨认导流流量
- 配对表与登记规矩见 `sites.md`「矩阵导流」节；只推功能相邻站，不硬推
